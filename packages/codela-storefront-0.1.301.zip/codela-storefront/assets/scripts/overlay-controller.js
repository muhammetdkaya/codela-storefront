import { animatePanelTransform } from 'codela-storefront/panel-motion';

/**
 * Single overlay controller. Owns the responsive search slot, native dialog, active view,
 * focus, scroll locking/restoration and content transitions.
 * The navigation element is passed by callback and is never duplicated.
 */
export function createOverlayController({
    $, config, t, searchFeature, cartFeature,
    mountDock, restoreDock, setDockCollapsed, markDockActive, mobileDock,
    dockScrollPositions, onMenuOpen,
}) {
    let dialog = null, current = null, opener = null, savedY = 0;
    let savedBodyStyle = null, savedAdminStyle = null, panelMotion = null;
    let surfaceMotion = null, closing = false, restoreScrollFrame = 0;
    let menuTrigger = null, menuHome = null, menuLabel = '';
    const desktop = window.matchMedia('(min-width:901px)');
    const desktopMenu = window.matchMedia('(min-width:1100px)');
    const mobileHeader = window.matchMedia('(max-width:700px)');
    let returnToPanel = null;
    let inlineSearch = false, searchHome = null, searchSlot = null, hiddenHeaderControl = null;
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

    function panelTiming(element, out = false) {
        const style = getComputedStyle(element);
        const time = style.getPropertyValue('--sf-ui-motion-panel-' + (out ? 'exit' : 'enter')).trim();
        const duration = parseFloat(time) * (time.endsWith('ms') ? 1 : 1000);
        return {duration:reducedMotion.matches ? 0 : (Number.isFinite(duration) ? Math.max(0, duration) : 0),
            easing:style.getPropertyValue('--sf-ui-ease-press').trim() || 'ease-out'};
    }

    function adminOffset() {
        const bar = $('#wpadminbar');
        const rect = bar?.getBoundingClientRect();
        const visible = bar && getComputedStyle(bar).display !== 'none' && getComputedStyle(bar).visibility !== 'hidden';
        const offset = `${visible ? Math.max(0, Math.min(rect.bottom, rect.height)) : 0}px`;
        document.querySelector('.sf-header')?.style.setProperty('--sf-header-offset', offset);
        dialog?.style.setProperty('--sf-admin-offset', offset);
    }
    function rememberStyle(element, properties) {
        return properties.map(name => [name, element.style.getPropertyValue(name), element.style.getPropertyPriority(name)]);
    }
    function restoreStyle(element, values) {
        for (const [name, value, priority] of values || []) {
            if (value) element.style.setProperty(name, value, priority);
            else element.style.removeProperty(name);
        }
    }

    function searchSemantics() {
        document.querySelectorAll('[data-panel="search"]').forEach(trigger => {
            trigger.setAttribute('aria-controls', desktop.matches ? 'sf-search' : 'sf-panel');
            if (desktop.matches) trigger.removeAttribute('aria-haspopup');
            else trigger.setAttribute('aria-haspopup', 'dialog');
        });
    }
    function syncInlineHeaderControl() {
        if (!inlineSearch) return;
        const header = searchSlot.closest('.sf-header');
        const navigation = header.querySelector('.sf-desktop-navigation');
        const control = navigation && desktopMenu.matches ? navigation : header.querySelector('.sf-brand');
        if (hiddenHeaderControl !== control) {
            if (hiddenHeaderControl) hiddenHeaderControl.inert = false;
            hiddenHeaderControl = control;
            hiddenHeaderControl.inert = true;
        }
    }
    function openInlineSearch(event) {
        if (inlineSearch) { $('#sf-query').focus({preventScroll:true}); return; }
        if (dialog.open) finishClose();
        opener = event?.target?.closest?.('[data-panel]') || event?.currentTarget || document.activeElement;
        current = 'search'; inlineSearch = true;
        const header = searchSlot.closest('.sf-header');
        syncInlineHeaderControl();
        header.classList.add('is-search-expanded');
        searchSlot.hidden = false;
        searchSlot.appendChild($('#sf-search'));
        $('#sf-search').hidden = false;
        $('.sf-search-content').classList.add('sf-ui-surface');
        $('.sf-search-toolbar').classList.add('sf-ui-surface');
        document.querySelectorAll('[data-panel="search"]').forEach(el => el.setAttribute('aria-expanded','true'));
        document.querySelectorAll('.sf-desktop-submenu:popover-open').forEach(menu => menu.hidePopover());
        if (!reducedMotion.matches && searchSlot.animate) {
            const toolbar = searchSlot.querySelector('.sf-search-toolbar');
            const rect = toolbar.getBoundingClientRect();
            const trigger = document.querySelector('.sf-header [data-panel="search"]')?.getBoundingClientRect();
            const offset = trigger ? trigger.right - rect.right : 0;
            const motion = toolbar.animate([
                {clipPath:`inset(0 0 0 ${Math.max(0, rect.width - 44)}px round 24px)`, transform:`translateX(${offset}px)`},
                {clipPath:'inset(0 0 0 0 round 24px)', transform:'translateX(0)'},
            ], panelTiming(toolbar));
            surfaceMotion = motion;
            motion.onfinish = () => { if (surfaceMotion === motion) surfaceMotion = null; };
        }
        searchFeature.start();
        $('#sf-query').focus({preventScroll:true});
    }
    function closeInlineSearch(restoreFocus = true) {
        surfaceMotion?.cancel(); surfaceMotion = null;
        searchFeature.cancel();
        const search = $('#sf-search');
        search.hidden = true;
        searchHome.after(search);
        $('.sf-search-content').classList.remove('sf-ui-surface');
        $('.sf-search-toolbar').classList.remove('sf-ui-surface');
        searchSlot.hidden = true;
        searchSlot.closest('.sf-header').classList.remove('is-search-expanded');
        if (hiddenHeaderControl) hiddenHeaderControl.inert = false;
        hiddenHeaderControl = null;
        document.querySelectorAll('[data-panel="search"]').forEach(el => el.setAttribute('aria-expanded','false'));
        inlineSearch = false; current = null;
        if (restoreFocus && opener?.isConnected) opener.focus({preventScroll:true});
        opener = null;
    }
    function animateDrawer(out = false, from = null) {
        if (reducedMotion.matches || !dialog.animate) return false;
        surfaceMotion?.cancel();
        surfaceMotion = null;
        const motion = animatePanelTransform(dialog,
            from || (out ? 'translateX(0)' : 'translateX(100%)'),
            out ? 'translateX(100%)' : 'translateX(0)', panelTiming(dialog, out));
        if (!motion) return false;
        surfaceMotion = motion;
        motion.onfinish = () => {
            if (surfaceMotion !== motion) return;
            if (out) finishClose();
            else { motion.cancel(); surfaceMotion = null; }
        };
        return true;
    }

    // One focusable menu trigger is reparented above the native dialog backdrop.
    function findMenuTrigger() {
        if (!menuTrigger) {
            menuTrigger = document.querySelector('.sf-header-menu [data-panel="menu"]');
            menuHome = menuTrigger?.parentElement || null;
            menuLabel = menuTrigger?.getAttribute('aria-label') || 'Menu';
        }
        return menuTrigger;
    }
    function positionMenuTrigger() {
        const trigger = findMenuTrigger();
        if (!trigger?.classList.contains('is-in-panel')) return;
        const nav = menuHome.getBoundingClientRect();
        const header = document.querySelector('.sf-header')?.getBoundingClientRect();
        dialog.style.setProperty('--sf-menu-control-x', nav.left + 'px');
        dialog.style.setProperty('--sf-menu-control-y', (header ? header.top + (header.height - 44) / 2 : nav.top) + 'px');
    }
    function mountMenuTrigger() {
        const trigger = findMenuTrigger();
        if (!trigger || trigger.classList.contains('is-in-panel')) return;
        const rect = trigger.getBoundingClientRect();
        dialog.style.setProperty('--sf-menu-control-x', rect.left + 'px');
        dialog.style.setProperty('--sf-menu-control-y', rect.top + 'px');
        dialog.appendChild(trigger);
        trigger.classList.add('is-in-panel');
    }
    function restoreMenuTrigger() {
        if (!menuTrigger?.classList.contains('is-in-panel')) return;
        menuTrigger.classList.remove('is-in-panel');
        menuTrigger.setAttribute('aria-label', menuLabel);
        menuTrigger.setAttribute('aria-expanded', 'false');
        menuHome.appendChild(menuTrigger);
        dialog?.style.removeProperty('--sf-menu-control-x');
        dialog?.style.removeProperty('--sf-menu-control-y');
    }
    function toggleMenu(event) {
        if (dialog?.open && current === 'menu' && !closing) {
            event?.preventDefault();
            if (mobileHeader.matches && returnToPanel) {
                const destination = returnToPanel;
                returnToPanel = null;
                open(destination, event);
            } else close();
        } else open('menu', event);
    }
    function open(name, event) {
        if (event && (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey)) return;
        // The native Cart page already displays the *actual* cart dialog
        // nodes. Do not open a second/empty cart dialog on that destination.
        if (name === 'cart' && cartFeature.isPageActive()) {
            event?.preventDefault();
            if (dialog?.open) close();
            cartFeature.focusPage();
            return;
        }
        event?.preventDefault();
        dialog ||= $('#sf-panel');
        if (!dialog || typeof dialog.showModal !== 'function') { if (name !== 'menu') location.href = config()[name] || config().shop; return; }
        if (name === 'search' && desktop.matches && searchSlot) { openInlineSearch(event); return; }
        if (inlineSearch) closeInlineSearch(false);
        const wasClosing = closing;
        // Capture before cancelling so a reversal starts at the rendered position,
        // not at the other endpoint. Only the desktop cart transforms its dialog.
        const drawerFrom = closing && current === 'cart' && name === 'cart' && desktop.matches && surfaceMotion
            ? getComputedStyle(dialog).transform : null;
        if (closing) {
            surfaceMotion?.cancel(); surfaceMotion = null;
            panelMotion?.cancel(); panelMotion = null;
            closing = false;
            dialog.classList.remove('is-closing');
        }
        const opening = !dialog.open;
        if (!opening && current === name && !wasClosing) return;
        surfaceMotion?.cancel(); surfaceMotion = null;
        const previous = current;
        // Cart has one presentation on every page, including single products.
        const appPanel = mobileHeader.matches && ['search','account','cart'].includes(name);
        if (name === 'menu' && mobileHeader.matches && ['search','cart','account'].includes(previous)) returnToPanel = previous;
        else if (name !== 'menu') returnToPanel = null;
        if (opening) {
            cancelAnimationFrame(restoreScrollFrame);
            document.documentElement.classList.add('sf-overlay-scroll-locked');
            opener = event?.target?.closest?.('[data-panel]') || event?.currentTarget || document.activeElement; savedY = window.scrollY;
            const bodyRect = document.body.getBoundingClientRect();
            savedBodyStyle = rememberStyle(document.body, ['position', 'top', 'width', 'padding-right']);
            const bar = $('#wpadminbar');
            if (bar) {
                const barRect = bar.getBoundingClientRect();
                savedAdminStyle = rememberStyle(bar, ['position', 'top']);
                // Mobile WordPress uses an absolute toolbar; keep its visible position
                // when the body becomes a new containing block.
                bar.style.position = 'fixed'; bar.style.top = `${barRect.top}px`;
            }
            const scrollbar = window.innerWidth - document.documentElement.clientWidth;
            if (scrollbar > 0) document.body.style.paddingRight = `${parseFloat(getComputedStyle(document.body).paddingRight) + scrollbar}px`;
            // Preserve the rendered body origin, including WordPress's html top margin.
            document.body.style.position = 'fixed'; document.body.style.top = `${bodyRect.top}px`; document.body.style.width = '100%';
            adminOffset();
            mountDock();
        }
        if (current === 'search' && name !== 'search') searchFeature.cancel();
        current = name;
        if (name === 'menu' || appPanel) mountMenuTrigger();
        else restoreMenuTrigger();
        if (appPanel) {
            const trigger = findMenuTrigger();
            trigger?.setAttribute('aria-label', menuLabel);
            trigger?.setAttribute('aria-expanded', 'false');
        }
        setDockCollapsed(false);
        dialog.classList.toggle('is-menu-panel', name === 'menu');
        dialog.classList.toggle('is-search-panel', name === 'search');
        dialog.classList.toggle('is-cart-panel', name === 'cart');
        // No product-only compact cart variant; the native dialog remains full-screen.
        dialog.classList.toggle('is-account-panel', name === 'account');
        dialog.classList.toggle('is-filters-panel', name === 'filters');
        const dock = mobileDock();
        if (dock && dock.parentElement === dialog) dock.hidden = name === 'menu';
        markDockActive(name);
        const menuTrigger = findMenuTrigger();
        dialog.setAttribute('aria-label', name === 'menu' ? menuLabel : name === 'search' ? t('Search products') : name === 'account' ? t('My account') : name === 'filters' ? t('Filters') : t('Your cart'));
        $('.sf-panel-top .sf-close').hidden = name === 'menu';
        dialog.removeAttribute('aria-labelledby');
        for (const section of ['menu','search','cart','account','filters']) {
            const panel = $(`#sf-${section}`);
            if (panel) panel.hidden = name !== section;
        }
        $('.sf-cart-bottom').hidden = name !== 'cart' || !cartFeature.getData()?.items.length;
        $('#sf-status').textContent = '';
        $('#sf-panel-title').textContent = name === 'menu' ? '' : name === 'search' ? t('Search products') : name === 'account' ? t('My account') : name === 'filters' ? t('Filters') : t('Your cart');
        document.querySelectorAll('[data-panel]').forEach(el => el.setAttribute('aria-expanded', String(el.dataset.panel === name && name !== 'menu')));
        dialog.classList.add('is-open');
        // Automatically focused controls should not display a giant focus ring
        // when opening a panel; keyboard navigation must still show its indicator.
        dialog.querySelectorAll('.sf-initial-focus').forEach(el => el.classList.remove('sf-initial-focus'));
        const initialFocus = (name === 'menu' || appPanel) ? (menuTrigger || $('.sf-close'))
            : name === 'search' ? $('.sf-search-cancel') : $('.sf-panel-top .sf-close');
        initialFocus.classList.add('sf-initial-focus');
        // Native dialog focuses this button even when a previous session focused the query.
        dialog.querySelectorAll('[autofocus]').forEach(el => el.removeAttribute('autofocus'));
        initialFocus.setAttribute('autofocus', '');
        if (opening) dialog.showModal();
        if (name === 'menu' && menuTrigger) {
            // Resolve initial line transforms before transitioning to an X.
            menuTrigger.getBoundingClientRect();
            menuTrigger.setAttribute('aria-label', t('Close'));
            menuTrigger.setAttribute('aria-expanded', 'true');
        }
        initialFocus.focus({preventScroll:true});
        if (name === 'menu') onMenuOpen();
        if (name === 'search') searchFeature.start();
        if (name === 'cart') cartFeature.refresh();
        if (name === 'account') {
            // Native Woo forms submit to My Account, not the page under the dialog.
            // Their login/registration handlers and nonces remain WooCommerce-owned.
            dialog.querySelectorAll('#sf-account form.woocommerce-form').forEach(form => {
                form.action = config().account;
            });
            // Present the dialog now; nonce/session refresh is asynchronous.
            // No page-wide skeleton or full navigation on the dock tap.
            $('#sf-account')?.dispatchEvent(new Event('codela:account-open'));
        }
        if (name === 'cart' && desktop.matches) animateDrawer(false, drawerFrom);
        else animatePanelContent(name === 'search' ? $('.sf-search-content') : $(`#sf-${name}`), previous === 'cart' && name === 'search' ? -1 : 1);
    }
    // Mobile transitions animate content only: transforming the dialog changes the
    // containing block of the fixed dock in some browsers. Repeated actions cancel cleanly.
    function animatePanelContent(element, direction = 1) {
        panelMotion?.cancel();
        panelMotion = null;
        if (reducedMotion.matches || !element?.animate) return;
        const menu = element.id === 'sf-menu';
        const motion = element.animate([
            {opacity:0, transform:menu ? 'translate3d(0,-16px,0)' : `translate3d(${direction * 8}px,0,0)`},
            {opacity:1, transform:'translate3d(0,0,0)'},
        ], panelTiming(element));
        panelMotion = motion;
        // finish events are queued: a completed older entrance must never
        // clear a replacement/closing animation's cancellation ownership.
        motion.onfinish = () => { if (panelMotion === motion) panelMotion = null; };
    }
    function close() {
        if (inlineSearch) { closeInlineSearch(); return; }
        if (!dialog?.open || closing) return;
        if (current === 'menu' && mobileHeader.matches && returnToPanel) {
            const destination = returnToPanel;
            returnToPanel = null;
            open(destination);
            return;
        }
        const drawerFrom = current === 'cart' && desktop.matches && surfaceMotion
            ? getComputedStyle(dialog).transform : null;
        panelMotion?.cancel(); panelMotion = null;
        surfaceMotion?.cancel(); surfaceMotion = null;
        if (current === 'menu') {
            findMenuTrigger()?.setAttribute('aria-expanded', 'false');
            menuTrigger?.setAttribute('aria-label', menuLabel);
        }
        if (current === 'cart' && desktop.matches && animateDrawer(true, drawerFrom)) {
            closing = true;
            dialog.classList.add('is-closing');
            return;
        }
        if (current === 'menu' && !reducedMotion.matches && $('#sf-menu')?.animate) {
            closing = true;
            const motion = $('#sf-menu').animate([
                {opacity:1,transform:'translate3d(0,0,0)'},
                {opacity:0,transform:'translate3d(0,-12px,0)'},
            ], {...panelTiming($('#sf-menu'), true),fill:'forwards'});
            panelMotion = motion;
            motion.onfinish = () => { if (panelMotion === motion) finishClose(); };
            return;
        }
        finishClose();
    }
    function finishClose(navigating = false) {
        surfaceMotion?.cancel(); surfaceMotion = null;
        panelMotion?.cancel(); panelMotion = null;
        closing = false;
        dialog.classList.remove('is-open', 'is-closing');
        document.querySelectorAll('[data-panel]').forEach(el => el.setAttribute('aria-expanded','false'));
        searchFeature.cancel();
        dialog.close(); restoreMenuTrigger(); current = null;
        returnToPanel = null;
        restoreDock();
        restoreStyle(document.body, savedBodyStyle); savedBodyStyle = null;
        const bar = $('#wpadminbar'); if (bar) restoreStyle(bar, savedAdminStyle);
        savedAdminStyle = null; dialog.style.removeProperty('--sf-admin-offset');
        if (!navigating) {
            window.scrollTo({top:savedY, left:0, behavior:'instant'});
            dockScrollPositions.set(window, {position:savedY, distance:0});
            if (opener?.isConnected) opener.focus({preventScroll:true});
        }
        cancelAnimationFrame(restoreScrollFrame);
        // Restore layout/position while native root snapping is still suspended.
        // Re-enable it only after the original product anchor is back in layout.
        document.documentElement.getBoundingClientRect();
        if (navigating) document.documentElement.classList.remove('sf-overlay-scroll-locked');
        else restoreScrollFrame = requestAnimationFrame(() => {
            restoreScrollFrame = 0;
            if (!dialog.open) document.documentElement.classList.remove('sf-overlay-scroll-locked');
        });
        opener = null;
    }
    
    function closeForNavigation() {
        // Closing the menu before a router click must not jump to the old
        // scroll position, restore focus to stale content, or wait for motion.
        if (inlineSearch) { closeInlineSearch(false); return; }
        if (!dialog?.open) return;
        panelMotion?.cancel(); panelMotion = null;
        surfaceMotion?.cancel(); surfaceMotion = null;
        finishClose(true);
    }

    function bind(element) {
        if (dialog && dialog !== element) throw new Error('Overlay controller already bound');
        if (dialog) return;
        dialog = element;
        searchSlot = $('.sf-header-search');
        searchHome = document.createComment('Search mobile slot');
        $('#sf-search').before(searchHome);
        searchSemantics();
        reducedMotion.addEventListener('change', () => {
            if (!reducedMotion.matches) return;
            if (closing) { finishClose(); return; }
            surfaceMotion?.cancel(); surfaceMotion = null;
            panelMotion?.cancel(); panelMotion = null;
        });
        desktop.addEventListener('change', () => {
            if (inlineSearch) closeInlineSearch();
            else if (dialog.open && current === 'search') finishClose();
            else if (dialog.open && current === 'cart') {
                // Keep the same cart, focus and scroll area while CSS changes
                // between drawer and fullscreen; the one dock is already inside.
                if (closing) finishClose();
                else {
                    surfaceMotion?.cancel(); surfaceMotion = null;
                    panelMotion?.cancel(); panelMotion = null;
                }
            }
            searchSemantics();
        });
        document.addEventListener('keydown', event => {
            if (inlineSearch && event.key === 'Escape') { event.preventDefault(); closeInlineSearch(); }
        });
        document.addEventListener('pointerdown', event => {
            if (inlineSearch && !searchSlot.contains(event.target) && !event.target.closest('[data-panel="search"]')) closeInlineSearch(false);
        });
        let backdropDown = false;
        const outsideDrawer = event => {
            const rect = dialog.getBoundingClientRect();
            return event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom;
        };
        dialog.addEventListener('pointerdown', event => { backdropDown = outsideDrawer(event); });
        dialog.addEventListener('click', event => {
            if (current === 'cart' && desktop.matches && backdropDown && outsideDrawer(event)) close();
            backdropDown = false;
        });
        adminOffset();
        desktopMenu.addEventListener('change', syncInlineHeaderControl);
        window.addEventListener('resize', () => { adminOffset(); positionMenuTrigger(); syncInlineHeaderControl(); });
        let offsetFrame = 0;
        window.addEventListener('scroll', () => {
            if (!offsetFrame) offsetFrame = requestAnimationFrame(() => {
                offsetFrame = 0;
                adminOffset();
            });
        }, {passive:true});
        dialog.addEventListener('cancel', event => {
            event.preventDefault();
            close();
        });
        dialog.addEventListener('keydown', event => {
            if (event.key === 'Tab') {
                dialog.querySelectorAll('.sf-initial-focus').forEach(el => el.classList.remove('sf-initial-focus'));
            }
        });
    }

    return {
        bind,
        open,
        toggleMenu,
        close,
        closeForNavigation,
        animateContent: animatePanelContent,
        getCurrent: () => current,
        getDialog: () => dialog,
    };
}
