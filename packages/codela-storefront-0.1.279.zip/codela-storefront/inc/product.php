<?php
/** Product purchase composition; WooCommerce owns every input and submission. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function codela_sf_product_information_tabs( array $tabs ): array {
    if ( ! isset( $tabs['additional_information'] ) ) {
        $tabs['additional_information'] = [
            'title' => __( 'Product specifications', 'codela-storefront' ),
            'priority' => 20,
            'callback' => 'woocommerce_product_additional_information_tab',
        ];
    }
    if ( isset( $tabs['additional_information'] ) ) { $tabs['additional_information']['title'] = __( 'Product specifications', 'codela-storefront' ); }
    return $tabs;
}

function codela_sf_product_stock_placement( string $html, $product ): string {
    // Keep variation availability in Woo's live selection data and AJAX responses.
    if ( ! is_product() || ! $product->is_in_stock() || $product->is_type( 'variation' ) || doing_action( 'woocommerce_product_additional_information' ) ) {
        return $html;
    }
    return '';
}

/**
 * Recompose only already-enabled Codela module callbacks. Never instantiate a
 * module, read its private settings, or duplicate its calculations/REST/JS.
 * Public WP_Hook callbacks let us retain the same instance and accepted args
 * even when a merchant chose a different summary priority in the plugin.
 */
function codela_sf_product_modules(): void {
    if ( ! function_exists( 'is_product' ) || ! is_product() ) { return; }
    global $wp_filter;
    $hook = $wp_filter['woocommerce_single_product_summary'] ?? null;
    if ( ! $hook instanceof WP_Hook ) { return; }
    $placements = [
        'Codela\\Modules\\LiveVisitor\\Module' => [ 'render_counter_container', 'woocommerce_product_thumbnails', 30 ],
        'Codela\\Modules\\UrgencyBadge\\Module' => [ 'render', 'woocommerce_single_product_summary', 11 ],
        'Codela\\Modules\\DeliveryEta\\Module' => [ 'render', 'woocommerce_single_product_summary', 32 ],
        'Codela\\Modules\\FreeShippingBar\\Module' => [ 'render_product', 'woocommerce_single_product_summary', 33 ],
        'Codela\\Modules\\WhatsappButton\\Module' => [ 'render_product', 'woocommerce_single_product_summary', 35 ],
        'Codela\\Modules\\TrustBadges\\Module' => [ 'render', 'woocommerce_single_product_summary', 36 ],
    ];
    foreach ( $hook->callbacks as $priority => $callbacks ) {
        foreach ( $callbacks as $entry ) {
            $callback = $entry['function'];
            if ( ! is_array( $callback ) || ! is_object( $callback[0] ) ) { continue; }
            $placement = $placements[ get_class( $callback[0] ) ] ?? null;
            if ( ! $placement || $callback[1] !== $placement[0] ) { continue; }
            remove_action( 'woocommerce_single_product_summary', $callback, $priority );
            $render = $callback;
            if ( 'render_counter_container' === $callback[1] || 'Codela\\Modules\\WhatsappButton\\Module' === get_class( $callback[0] ) ) {
                $render = static function() use ( $callback ) { codela_sf_product_module_output( $callback ); };
            }
            add_action( $placement[1], $render, $placement[2], (int) $entry['accepted_args'] );
        }
    }
    // Optional site-wide contact remains functional after its shared plugin
    // stylesheet is removed on product pages. Reuse the same IconButton.
    $footer = $wp_filter['wp_footer'] ?? null;
    if ( $footer instanceof WP_Hook ) {
        foreach ( $footer->callbacks as $priority => $callbacks ) {
            foreach ( $callbacks as $entry ) {
                $callback = $entry['function'];
                if ( is_array( $callback ) && is_object( $callback[0] )
                    && 'Codela\\Modules\\WhatsappButton\\Module' === get_class( $callback[0] ) && 'render_floating' === $callback[1] ) {
                    remove_action( 'wp_footer', $callback, $priority );
                    add_action( 'wp_footer', static function() use ( $callback ) { codela_sf_product_module_output( $callback ); }, $priority );
                }
            }
        }
    }
}

/** Decorate original, escaped module markup with shared component classes. */
function codela_sf_product_module_output( array $callback ): void {
    ob_start();
    call_user_func( $callback );
    $html = (string) ob_get_clean();
    $tags = new WP_HTML_Tag_Processor( $html );
    while ( $tags->next_tag() ) {
        if ( 'codela-live-visitor-container' === $tags->get_attribute( 'id' ) ) { $tags->add_class( 'sf-product-visitor' ); }
        if ( $tags->has_class( 'cdl-wa-ico' ) || $tags->has_class( 'cdl-wa-float' ) ) {
            foreach ( codela_sf_ui_icon_button_classes( 'soft' ) as $class ) { $tags->add_class( $class ); }
        }
    }
    $html = $tags->get_updated_html();
    if ( 'render_floating' === $callback[1] && '' !== trim( $html ) ) {
        $html = '<div class="sf-product-plugin-footer">' . $html . '</div>';
    }
    echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- original escaped module output; only controlled classes/wrapper added.
}

/** One CSS owner on product pages; scripts and every other page stay native. */
function codela_sf_product_module_styles(): void {
    if ( ! function_exists( 'is_product' ) || ! is_product() ) { return; }
    // Shared saved corner/font tokens may have been attached to a plugin
    // handle before the theme enqueued. Retain those settings on our sole
    // product handle rather than retaining the plugin's component paint.
    $tokens = function_exists( 'codela_storefront_design_tokens' ) ? codela_storefront_design_tokens() : null;
    if ( is_array( $tokens ) ) {
        wp_add_inline_style( 'codela-storefront-product', 'body{--cdl-ct-radius:' . $tokens[0]
            . ';--cdl-ct-box-radius:' . $tokens[1] . ';'
            . ( null !== $tokens[2] ? '--cdl-ct-font:' . $tokens[2] . ';' : '' ) . '}' );
    }
    foreach ( [ 'conversion-tools', 'live-visitor', 'urgency-badge', 'delivery-eta', 'free-shipping-bar', 'trust-badges', 'whatsapp-button' ] as $handle ) {
        wp_dequeue_style( 'codela-' . $handle );
    }
    // The optional global WhatsApp link shares its stylesheet with the inline
    // one, so the theme owns its presentation too, only on this product page.
}
add_action( 'wp_print_styles', 'codela_sf_product_module_styles', 110 );

function codela_sf_product_description_heading( string $heading ): string {
    return doing_action( 'codela_sf_product_information' ) ? '' : $heading;
}
add_filter( 'woocommerce_product_description_heading', 'codela_sf_product_description_heading' );
add_filter( 'woocommerce_product_additional_information_heading', 'codela_sf_product_description_heading' );

/** Resolve native tabs once for this product, before rendering either region. */
function &codela_sf_product_information_state(): array {
    global $product;
    static $states = [];
    $key = is_object( $product ) ? spl_object_id( $product ) : 0;
    if ( ! isset( $states[ $key ] ) ) {
        $states[ $key ] = [ 'product' => $product, 'tabs' => apply_filters( 'woocommerce_product_tabs', [] ), 'description_rendered' => false ];
    }
    return $states[ $key ];
}

/** One native callback and one ID, whether placed in summary or information. */
function codela_sf_product_information_section( string $key, array $tab ): void {
    ?>
    <details class="sf-product-information-section" id="sf-product-section-<?php echo esc_attr( $key ); ?>" <?php echo 'description' === $key ? 'open' : ''; ?>>
        <summary><?php echo wp_kses_post( apply_filters( 'woocommerce_product_' . $key . '_tab_title', $tab['title'], $key ) ); ?></summary>
        <div class="sf-product-information-content" id="tab-<?php echo esc_attr( $key ); ?>">
            <?php
            if ( isset( $tab['callback'] ) && is_callable( $tab['callback'] ) ) {
                $render_tab = static function() use ( $tab, $key ) { call_user_func( $tab['callback'], $key, $tab ); };
                add_action( 'codela_sf_product_information', $render_tab );
                do_action( 'codela_sf_product_information' );
                remove_action( 'codela_sf_product_information', $render_tab );
            }
            ?>
        </div>
    </details>
    <?php
}

function codela_sf_product_summary_description(): void {
    $state =& codela_sf_product_information_state();
    if ( ! $state['description_rendered'] && isset( $state['tabs']['description'] ) ) {
        codela_sf_product_information_section( 'description', $state['tabs']['description'] );
        $state['description_rendered'] = true;
    }
}

add_action( 'wp', function() {
    if ( ! function_exists( 'is_product' ) || ! is_product() ) { return; }
    // Bound desktop sticky media to the overview, before information/recommendations.
    // display:contents keeps the original mobile document and sheet ownership.
    add_action( 'woocommerce_before_single_product_summary', function() { echo '<div class="sf-product-overview">'; }, 0 );
    add_action( 'woocommerce_before_single_product_summary', function() { echo '<div class="sf-product-media">'; }, 19 );
    add_action( 'woocommerce_before_single_product_summary', function() { echo '</div>'; }, 21 );
    add_action( 'woocommerce_after_single_product_summary', function() { echo '</div>'; }, 0 );
    add_action( 'woocommerce_single_product_summary', function() { echo '<div class="sf-product-price-row">'; }, 9 );
    add_action( 'woocommerce_single_product_summary', function() { echo '</div>'; }, 12 );
    // Desktop/tablet description is already in its final position at first
    // paint. Only the mobile sheet moves this same node into its disclosures.
    add_action( 'woocommerce_single_product_summary', 'codela_sf_product_summary_description', 31 );
    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
    add_filter( 'woocommerce_product_tabs', 'codela_sf_product_information_tabs', 20 );
    add_filter( 'woocommerce_get_stock_html', 'codela_sf_product_stock_placement', 20, 2 );
    add_action( 'woocommerce_product_additional_information', 'woocommerce_template_single_meta', 20 );
    add_action( 'woocommerce_product_additional_information', function() {
        global $product;
        if ( $product ) { echo wc_get_stock_html( $product ); }
    }, 21 );
    // Wrap the existing quantity/button, inside the original Woo form.
    // No cloned controls, click proxy, extra endpoint or purchase controller.
    add_action( 'woocommerce_before_add_to_cart_button', function() {
        echo '<div class="sf-product-purchase">';
    }, 0 );
    add_action( 'woocommerce_after_add_to_cart_button', function() {
        echo '</div>';
    }, PHP_INT_MAX );
} );
add_action( 'wp', 'codela_sf_product_modules', 100 );

/** Native quantity stays the submitted value; shared buttons only step it. */
function codela_sf_product_quantity_step( string $direction ): void {
    if ( ! function_exists( 'is_product' ) || ! is_product() ) { return; }
    echo codela_sf_ui_button( 'decrease' === $direction ? '−' : '+', [
        'variant' => 'quiet', 'class' => 'sf-product-quantity-step',
        'attributes' => [
            'data-quantity-step' => 'decrease' === $direction ? '-1' : '1',
            'aria-label' => 'decrease' === $direction ? __( 'Decrease quantity', 'codela-storefront' ) : __( 'Increase quantity', 'codela-storefront' ),
        ],
    ] );
}
add_action( 'woocommerce_before_quantity_input_field', static function() { codela_sf_product_quantity_step( 'decrease' ); } );
add_action( 'woocommerce_after_quantity_input_field', static function() { codela_sf_product_quantity_step( 'increase' ); } );

/** Hide the transient native summary only while its early adapter is loading.
 * No-JS keeps the native document; a failed/blocked adapter fails open.
 */
function codela_sf_product_sheet_bootstrap(): void {
    if ( ! function_exists( 'is_product' ) || ! is_product() ) { return; }
    // The viewport meta may not have been parsed yet. Let the CSS media query
    // decide visibility; never sample the provisional mobile layout width here.
    // A slow parser/network must not expire the guard while still loading.
    wp_print_inline_script_tag( <<<'JS'
(function(){
  // The real product sheet owns the first visible mobile layout. Do not
  // expose native summary just because parsing ends before its adapter runs.
  var root=document.documentElement;
  root.classList.add('sf-product-sheet-pending');
  function ready(){return document.body && document.body.classList.contains('sf-product-sheet-ready');}
  function fallback(){if(!ready())root.classList.remove('sf-product-sheet-pending');}
  document.addEventListener('DOMContentLoaded',function(){
    // The theme adapter can only mount when Woo rendered a real product.
    // If Woo did not render one, let the native fallback become visible.
    if(!document.getElementById('sf-product-sheet-template') ||
       !document.querySelector('.woocommerce-product-gallery'))fallback();
  },{once:true});
  // Load waits for normal, defer and async scripts; a missing/failed adapter
  // must not leave a native WooCommerce product permanently concealed.
  window.addEventListener('load',fallback,{once:true});
  window.addEventListener('error',function(event){
    if(event.target && event.target.id==='codela-storefront-product-information-js')fallback();
  },true);
})();
JS
    , [ 'id' => 'sf-product-sheet-bootstrap' ] );
}
add_action( 'wp_head', 'codela_sf_product_sheet_bootstrap', 1 );

/** Progressive mobile sheet: the script moves existing nodes, never copies a form. */
function codela_sf_product_sheet_template(): void {
    ?>
    <template id="sf-product-sheet-template" data-open-label="<?php esc_attr_e( 'Options and details', 'codela-storefront' ); ?>" data-close-label="<?php esc_attr_e( 'Close product details', 'codela-storefront' ); ?>" data-shipping-label="<?php esc_attr_e( 'Ships %s', 'codela-storefront' ); ?>" data-gallery-label="<?php esc_attr_e( 'Product images', 'codela-storefront' ); ?>" data-previous-image-label="<?php esc_attr_e( 'Previous image', 'codela-storefront' ); ?>" data-next-image-label="<?php esc_attr_e( 'Next image', 'codela-storefront' ); ?>" data-fullscreen-label="<?php esc_attr_e( 'Open fullscreen gallery', 'codela-storefront' ); ?>" data-delivery-label="<?php esc_attr_e( 'Delivery and shipping', 'codela-storefront' ); ?>">
        <section class="sf-product-sheet sf-ui-surface sf-ui-surface--glass-panel" aria-label="<?php esc_attr_e( 'Product details', 'codela-storefront' ); ?>">
            <header class="sf-product-sheet-header">
                <div class="sf-product-sheet-heading"></div>
                <button type="button" class="sf-product-sheet-toggle sf-ui-button sf-ui-button--quiet" aria-label="<?php esc_attr_e( 'Options and details', 'codela-storefront' ); ?>" aria-expanded="false" aria-controls="sf-product-sheet-body">
                    <span class="sf-ui-button-label"><?php echo esc_html( __( 'Options and details', 'codela-storefront' ) ); ?></span>
                    <?php echo codela_sf_product_sheet_handle_svg(); ?>
                </button>
            </header>
            <div class="sf-product-sheet-body" id="sf-product-sheet-body"></div>
        </section>
    </template>
    <?php
    ?>
    <template id="sf-product-gallery-controls-template"><div class="sf-product-gallery-arrows">
        <?php echo codela_sf_ui_icon_button( 'arrow-left', __( 'Previous image', 'codela-storefront' ), [ 'variant' => 'soft', 'attributes' => [ 'data-product-gallery-step' => '-1' ] ] ); ?>
        <?php echo codela_sf_ui_icon_button( 'arrow-right', __( 'Next image', 'codela-storefront' ), [ 'variant' => 'soft', 'attributes' => [ 'data-product-gallery-step' => '1' ] ] ); ?>
    </div></template>
    <?php
    // Product DOM is complete here. Print the dependency-free adapter before
    // unrelated footer scripts, once through WordPress's existing script queue.
    wp_print_scripts( [ 'codela-storefront-product-information' ] );
}
add_action( 'woocommerce_after_single_product_summary', 'codela_sf_product_sheet_template', 99 );



/** Purchase confirmation stays in the existing cart badge/control, not a Woo banner. */
add_filter( 'wc_add_to_cart_message_html', static function( $message ) {
    return '<span data-sf-cart-added hidden></span>';
} );


/**
 * Confirm a successful ORIGINAL WooCommerce form POST independently of theme
 * notices, which plugins and Woo blocks may filter out. The form handler
 * still owns stock validation, variation choices, extra fields, and cookies.
 * This only adds a response header to our same-origin progressive request.
 */
add_action( 'woocommerce_add_to_cart', static function() {
    if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' )
        || empty( $_POST['codela_sf_cart_async'] )
        || empty( $_POST['add-to-cart'] ) ) {
        return;
    }
    $GLOBALS['codela_sf_cart_added'] = true;
    if ( ! headers_sent() ) { header( 'X-Codela-Sf-Cart-Added: 1' ); }
}, 10, 0 );

// Keep this in-page progressive request in place even when the store normally
// sends traditional add-to-cart forms to the cart immediately.
add_filter( 'woocommerce_add_to_cart_redirect', static function( $url ) {
    return ! empty( $_POST['codela_sf_cart_async'] ) ? false : $url;
}, 999 );
add_filter( 'option_woocommerce_cart_redirect_after_add', static function( $value ) {
    return ! empty( $_POST['codela_sf_cart_async'] ) ? 'no' : $value;
}, 999 );

/** Finish after Woo's wp_loaded:20 native form handler, before page rendering.
 * Confirmation must not depend on HTML notices or a subsequent redirect.
 * This request never calls add_to_cart a second time.
 */
function codela_sf_cart_async_result(): void {
    if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' )
        || '1' !== ( $_POST['codela_sf_cart_async'] ?? '' )
        || empty( $_POST['add-to-cart'] ) || ! function_exists( 'wc_get_notices' ) ) { return; }
    $errors = array_map( static function( $notice ) {
        return wp_strip_all_tags( is_array( $notice ) ? ( $notice['notice'] ?? '' ) : $notice );
    }, wc_get_notices( 'error' ) );
    $added = ! empty( $GLOBALS['codela_sf_cart_added'] );
    wc_clear_notices();
    nocache_headers();
    wp_send_json( [ 'codela_cart_result' => true, 'added' => $added,
        'message' => implode( ' ', $errors ) ], $added ? 200 : 422 );
}
add_action( 'wp_loaded', 'codela_sf_cart_async_result', 30 );
