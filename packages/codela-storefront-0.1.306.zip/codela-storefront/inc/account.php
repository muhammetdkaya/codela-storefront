<?php
/**
 * Storefront owns account presentation through the existing Theme appearance mode.
 * WooCommerce owns native forms/endpoints; Codela modules retain their hooks.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Display a welcome heading exclusively above the native guest login form. */
function codela_sf_account_intro(): void {
    if (
        ! function_exists( 'is_account_page' )
        || ( ! is_account_page() && empty( $GLOBALS['codela_sf_auth_overlay'] ) )
        || is_user_logged_in()
    ) {
        return;
    }
    ?>
    <header class="sf-account-intro"
        data-auth-initial="<?php echo isset( $_POST['register'] ) ? 'register' : 'login'; ?>"
        data-auth-login-placeholder="<?php esc_attr_e( 'Email address', 'codela-storefront' ); ?>"
        data-auth-username-placeholder="<?php esc_attr_e( 'Username', 'codela-storefront' ); ?>"
        data-auth-email-placeholder="<?php esc_attr_e( 'Email address', 'codela-storefront' ); ?>"
        data-auth-password-placeholder="<?php esc_attr_e( 'Password', 'codela-storefront' ); ?>"
        data-auth-login-title="<?php esc_attr_e( 'Welcome back', 'codela-storefront' ); ?>"
        data-auth-login-description="<?php esc_attr_e( 'Sign in to your account.', 'codela-storefront' ); ?>"
        data-auth-register-title="<?php esc_attr_e( 'Create an account', 'codela-storefront' ); ?>"
        data-auth-register-description="<?php esc_attr_e( 'Join us in a few steps.', 'codela-storefront' ); ?>"
        data-auth-lookup-url="<?php echo function_exists( 'admin_url' ) && function_exists( 'esc_attr' ) ? esc_attr( admin_url( 'admin-ajax.php' ) ) : ''; ?>"
        data-auth-lookup-nonce="<?php echo function_exists( 'wp_create_nonce' ) && function_exists( 'esc_attr' ) ? esc_attr( wp_create_nonce( 'codela_sf_auth_lookup' ) ) : ''; ?>"
        data-auth-smart-label="<?php esc_attr_e( 'Your email address', 'codela-storefront' ); ?>"
        data-auth-smart-missing-at="<?php esc_attr_e( 'Add @ to your email address.', 'codela-storefront' ); ?>"
        data-auth-smart-incomplete="<?php esc_attr_e( 'Complete your email address.', 'codela-storefront' ); ?>"
        data-auth-smart-register-action="<?php esc_attr_e( 'Register', 'codela-storefront' ); ?>"
        data-auth-smart-checking="<?php esc_attr_e( 'Checking account…', 'codela-storefront' ); ?>"
        data-auth-smart-error="<?php esc_attr_e( 'Account check is unavailable. You can still sign in or create an account.', 'codela-storefront' ); ?>"
        data-auth-smart-closed="<?php esc_attr_e( 'New account registration is currently unavailable.', 'codela-storefront' ); ?>"
        data-auth-smart-confirm="<?php esc_attr_e( 'Please enter a valid email address.', 'codela-storefront' ); ?>"
        data-auth-smart-continue="<?php esc_attr_e( 'Continue with email', 'codela-storefront' ); ?>"
        data-auth-smart-register-password="<?php esc_attr_e( 'Password (at least 8 characters)', 'codela-storefront' ); ?>"
        data-auth-smart-strength-min="<?php esc_attr_e( 'At least 8 characters', 'codela-storefront' ); ?>"
        data-auth-smart-strength-mix="<?php esc_attr_e( 'Include letters and a number or symbol', 'codela-storefront' ); ?>"
        data-auth-smart-strength-ok="<?php esc_attr_e( 'Password meets requirements', 'codela-storefront' ); ?>"
        data-auth-smart-strength-strong="<?php esc_attr_e( 'Strong password', 'codela-storefront' ); ?>"
        data-auth-smart-password-link="<?php esc_attr_e( 'Your password setup link will be sent by email.', 'codela-storefront' ); ?>"
        data-auth-smart-name-required="<?php esc_attr_e( 'Enter your first and last name.', 'codela-storefront' ); ?>"
        data-auth-smart-first="<?php esc_attr_e( 'First name', 'codela-storefront' ); ?>"
        data-auth-smart-last="<?php esc_attr_e( 'Last name', 'codela-storefront' ); ?>"
        data-auth-smart-title="<?php esc_attr_e( 'Welcome', 'codela-storefront' ); ?>"
        data-auth-smart-description="<?php esc_attr_e( 'Sign in or register.', 'codela-storefront' ); ?>">
        <h1 id="sf-auth-view-title"><span class="sf-auth-heading-text"><?php esc_html_e( 'Welcome back', 'codela-storefront' ); ?></span> <span class="sf-auth-heading-wave" aria-hidden="true">👋</span></h1>
        <p class="sf-auth-description"><?php esc_html_e( 'Sign in to your account.', 'codela-storefront' ); ?></p>
    </header>
    <?php
}

add_action( 'woocommerce_before_customer_login_form', 'codela_sf_account_intro', 5 );

/**
 * Render registration BETWEEN the completed Woo account forms and Google's
 * social offer. Never print the CTA from inside a Woo form-row: native submit /
 * remember-me layouts can give form-end hooks a narrow column and reorder it.
 * WooCommerce still owns both forms, validation, and registration permissions.
 */
function codela_sf_account_register_action(): void {
    if ( is_user_logged_in() || 'yes' !== get_option( 'woocommerce_enable_myaccount_registration', 'no' )
        || ( ! is_account_page() && empty( $GLOBALS['codela_sf_auth_overlay'] ) ) ) { return; }
    ?>
    <a href="#sf-auth-register" class="sf-auth-register-cta sf-ui-pressable" aria-controls="sf-auth-register">
        <span class="sf-auth-register-glyph" aria-hidden="true">
            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" focusable="false">
                <rect x="2.5" y="5" width="19" height="14" rx="2"/><path d="m3 6 9 7 9-7"/>
            </svg>
        </span>
        <span><?php esc_html_e( 'Register with email', 'codela-storefront' ); ?></span>
    </a>
    <?php
}
add_action( 'woocommerce_after_customer_login_form', 'codela_sf_account_register_action', 10 );

/** Registration stays the native WooCommerce form; returning never focuses an input. */
function codela_sf_account_login_return(): void {
    if ( is_user_logged_in() || ( ! is_account_page() && empty( $GLOBALS['codela_sf_auth_overlay'] ) ) ) { return; }
    ?>
    <a href="#customer_login" class="sf-auth-back-login sf-ui-pressable" aria-controls="sf-auth-login">
        <span aria-hidden="true">‹</span><?php esc_html_e( 'Back to sign in', 'codela-storefront' ); ?>
    </a>
    <?php
}
add_action( 'woocommerce_register_form_start', 'codela_sf_account_login_return', 12 );

/**
 * Native WooCommerce registration remains the only account-creation engine.
 * First and last name are submitted with its own nonce and native form.
 */
function codela_sf_auth_registration_names(): void {
    if ( is_user_logged_in() || ( ! is_account_page() && empty( $GLOBALS['codela_sf_auth_overlay'] ) )
        || 'yes' !== get_option( 'woocommerce_enable_myaccount_registration', 'no' ) ) { return; }
    $first = isset( $_POST['first_name'] ) && is_string( $_POST['first_name'] )
        ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '';
    $last = isset( $_POST['last_name'] ) && is_string( $_POST['last_name'] )
        ? sanitize_text_field( wp_unslash( $_POST['last_name'] ) ) : '';
    echo '<div class="sf-smart-name-fields">';
    echo '<p class="form-row form-row-first"><label for="sf-smart-first">'
        . esc_html__( 'First name', 'codela-storefront' ) . '</label>'
        . '<input type="text" class="input-text" id="sf-smart-first" name="first_name" autocomplete="given-name"'
        . ' maxlength="70" required value="' . esc_attr( $first ) . '" /></p>';
    echo '<p class="form-row form-row-last"><label for="sf-smart-last">'
        . esc_html__( 'Last name', 'codela-storefront' ) . '</label>'
        . '<input type="text" class="input-text" id="sf-smart-last" name="last_name" autocomplete="family-name"'
        . ' maxlength="70" required value="' . esc_attr( $last ) . '" /></p>';
    echo '</div>';
}
add_action( 'woocommerce_register_form_start', 'codela_sf_auth_registration_names', 14 );
// Even with JS disabled, Woo rejects empty name fields instead of accepting
// an incomplete account. Existing Woo validation and email checks still run.
add_filter( 'woocommerce_registration_errors', static function( $errors, $username, $email ) {
    if ( empty( $_POST['register'] ) ) { return $errors; }
    foreach ( [ 'first_name', 'last_name' ] as $field ) {
        $value = isset( $_POST[$field] ) && is_string( $_POST[$field] )
            ? trim( sanitize_text_field( wp_unslash( $_POST[$field] ) ) ) : '';
        if ( '' === $value ) {
            $errors->add( 'codela_sf_missing_' . $field,
                __( 'Please enter your first and last name.', 'codela-storefront' ) );
            break;
        }
    }
    return $errors;
}, 10, 3 );
add_action( 'woocommerce_created_customer', static function( $customer_id ): void {
    if ( empty( $_POST['register'] ) ) { return; }
    foreach ( [ 'first_name', 'last_name' ] as $key ) {
        if ( isset( $_POST[$key] ) && is_string( $_POST[$key] ) ) {
            update_user_meta( (int) $customer_id, $key, substr(
                sanitize_text_field( wp_unslash( $_POST[$key] ) ), 0, 255
            ) );
        }
    }
}, 10, 1 );

/**
 * Read-only EMAIL lookup, never a username-enumeration endpoint.
 * Rate limited per remote IP, guest-nonce guarded and no raw emails logged.
 * Actual login and registration are still handled exclusively by Woo.
 */
function codela_sf_auth_lookup(): void {
    nocache_headers();
    if ( is_user_logged_in() ) {
        wp_send_json( [ 'status' => 'authenticated' ] );
        return;
    }
    if ( ! check_ajax_referer( 'codela_sf_auth_lookup', 'token', false ) ) {
        wp_send_json( [ 'status' => 'unavailable' ], 403 );
        return;
    }
    $email = isset( $_POST['identity'] ) && is_string( $_POST['identity'] )
        ? sanitize_email( wp_unslash( $_POST['identity'] ) ) : '';
    if ( strlen( $email ) > 254 || ! is_email( $email ) ) {
        wp_send_json( [ 'status' => 'unavailable' ], 400 );
        return;
    }
    $ip = isset( $_SERVER['REMOTE_ADDR'] ) && is_string( $_SERVER['REMOTE_ADDR'] )
        ? $_SERVER['REMOTE_ADDR'] : '';
    $budget_key = 'sf_auth_lookup_' . hash_hmac( 'sha256', $ip, wp_salt( 'auth' ) );
    $hits = (int) get_transient( $budget_key );
    if ( $hits >= 18 ) {
        wp_send_json( [ 'status' => 'unavailable' ], 429 );
        return;
    }
    set_transient( $budget_key, $hits + 1, 15 * MINUTE_IN_SECONDS );
    $existing = (bool) email_exists( $email );
    $registration = 'yes' === get_option( 'woocommerce_enable_myaccount_registration', 'no' );
    wp_send_json( [ 'status' => $existing ? 'existing' : ( $registration ? 'new' : 'closed' ) ] );
}
add_action( 'wp_ajax_nopriv_codela_sf_auth_lookup', 'codela_sf_auth_lookup' );


/** WordPress admin login and recovery are intentionally preserved. */
function codela_sf_login_is_admin_destination( $redirect ): bool {
    if ( ! is_string( $redirect ) || '' === $redirect ) { return false; }
    $path = parse_url( $redirect, PHP_URL_PATH );
    return is_string( $path ) && ( str_contains( $path, '/wp-admin/' ) || str_ends_with( $path, '/wp-admin' ) );
}

/** Storefront authentication lives on WooCommerce My Account, not wp-login.php.
 * Keep WordPress's administrative login, reauthentication, password recovery,
 * logout and external identity callbacks fully operational.
 */
function codela_sf_public_login_destination( array $query, string $method = 'GET' ): string {
    if ( 'GET' !== strtoupper( $method ) || ! function_exists( 'wc_get_page_permalink' ) ) { return ''; }
    $action = $query['action'] ?? 'login';
    if ( ! is_string( $action ) || ! in_array( $action, [ '', 'login', 'register' ], true ) ) { return ''; }
    // Keep administrative wp-login requests native, but not ordinary storefront redirects.
    if ( isset( $query['redirect_to'] ) && codela_sf_login_is_admin_destination( $query['redirect_to'] ) ) { return ''; }
    foreach ( [ 'reauth', 'interim-login', 'checkemail', 'key', 'login' ] as $param ) {
        if ( isset( $query[ $param ] ) ) { return ''; }
    }
    return (string) wc_get_page_permalink( 'myaccount' );
}
add_action( 'login_init', static function(): void {
    $method = isset( $_SERVER['REQUEST_METHOD'] ) && is_string( $_SERVER['REQUEST_METHOD'] )
        ? $_SERVER['REQUEST_METHOD'] : 'GET';
    $destination = codela_sf_public_login_destination( $_GET, $method );
    if ( ! $destination ) { return; }
    nocache_headers();
    wp_safe_redirect( $destination, 302, 'Codela Storefront' );
    exit;
}, 5 );

/** Native front-end login/register links resolve to My Account. Admin login
 * URLs are deliberately left alone, including WP-CLI and password reset flows.
 */
add_filter( 'login_url', static function( $url, $redirect, $force_reauth ) {
    if ( is_admin() || $force_reauth || codela_sf_login_is_admin_destination( $redirect ) ) { return $url; }
    $account = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : '';
    return $account ?: $url;
}, 20, 3 );

/** Keep successful public logins on My Account, with cache-safe session URLs. */
function codela_sf_signed_in_account_url( $redirect ) {
    if ( ! function_exists( 'wc_get_page_permalink' ) ) { return $redirect; }
    $account = (string) wc_get_page_permalink( 'myaccount' );
    if ( '' === $account ) { return $redirect; }
    // A WooCommerce confirmation email opened while signed out needs its
    // one-time key preserved through login, otherwise verification cannot finish.
    // This is still the My Account URL; core validates and consumes the key.
    if ( isset( $_REQUEST['wc_verify_email_key'], $_REQUEST['wc_verify_email_user'] )
        && is_string( $_REQUEST['wc_verify_email_key'] ) ) {
        $key = sanitize_text_field( wp_unslash( $_REQUEST['wc_verify_email_key'] ) );
        $id = absint( $_REQUEST['wc_verify_email_user'] );
        if ( '' !== $key && $id > 0 ) {
            return add_query_arg( [ 'wc_verify_email_key' => $key, 'wc_verify_email_user' => $id ], $account );
        }
    }
    return function_exists( 'codela_sf_quick_fresh_account_redirect' )
        ? codela_sf_quick_fresh_account_redirect( $account ) : $account;
}
add_filter( 'woocommerce_login_redirect', 'codela_sf_signed_in_account_url', 5 );
add_filter( 'woocommerce_registration_redirect', 'codela_sf_signed_in_account_url', 5 );
add_filter( 'login_redirect', static function( $redirect, $requested, $user ) {
    if ( is_wp_error( $user ) ) { return $redirect; }
    // A privileged, intentional wp-admin login must continue to reach wp-admin.
    if ( is_object( $user ) && ! is_wp_error( $user )
        && user_can( $user, 'manage_options' ) && codela_sf_login_is_admin_destination( $requested ) ) {
        return $redirect;
    }
    return codela_sf_signed_in_account_url( $redirect );
}, 25, 3 );

// Codela Consent Center registers its WordPress rewrite endpoint and its own
// Woo account callback, but does not add it to WC_Query's endpoint registry.
// Without this bridge, get_current_endpoint() and is_wc_endpoint_url() treat
// /my-account/communication-preferences/ as the dashboard. On mobile that
// leaves the dashboard menu visible instead of the requested separate screen.
// Register only when the plugin's real renderer is active: no phantom page.
add_filter( 'woocommerce_get_query_vars', static function( array $vars ): array {
    if ( function_exists( 'codela_consent_center_render_preferences_endpoint' )
        && has_action( 'woocommerce_account_communication-preferences_endpoint',
            'codela_consent_center_render_preferences_endpoint' ) ) {
        $vars['communication-preferences'] = 'communication-preferences';
    }
    return $vars;
}, 11 );

// Keep WooCommerce endpoint navigation and all registered plugin destinations.

/**
 * Refresh guest Woo form nonces when the instant dialog opens. A storefront
 * page may be publicly cached for longer than the WooCommerce login/register
 * nonce lifetime. This read-only endpoint returns fresh guest form tokens,
 * never an authentication token and never authenticates a customer.
 */
function codela_sf_account_form_state(): void {
    nocache_headers();
    wp_send_json( [
        'authenticated' => is_user_logged_in(),
        'login_nonce' => wp_create_nonce( 'woocommerce-login' ),
        'register_nonce' => wp_create_nonce( 'woocommerce-register' ),
        'lookup_nonce' => wp_create_nonce( 'codela_sf_auth_lookup' ),
        'registration' => 'yes' === get_option( 'woocommerce_enable_myaccount_registration', 'no' ),
    ] );
}
add_action( 'wp_ajax_nopriv_codela_sf_account_form_state', 'codela_sf_account_form_state' );
add_action( 'wp_ajax_codela_sf_account_form_state', 'codela_sf_account_form_state' );

/**
 * Render genuine WooCommerce login and optional registration forms inside the
 * existing Storefront dialog. No iframe, duplicate auth engine, or AJAX endpoint.
 * The native Woo template retains its own nonces, hooks and validation.
 */
function codela_sf_account_overlay_form(): string {
    if ( is_user_logged_in() || ! function_exists( 'wc_get_template' ) ) { return ''; }
    ob_start();
    $GLOBALS['codela_sf_auth_overlay'] = true;
    try {
        echo '<div class="woocommerce sf-overlay-auth" data-auth-state-url="' . esc_url( admin_url( 'admin-ajax.php' ) ) . '">';
        wc_get_template( 'myaccount/form-login.php' );
        echo '</div>';
    } finally {
        unset( $GLOBALS['codela_sf_auth_overlay'] );
    }
    return (string) ob_get_clean();
}

/** The signed-in account starts at its navigation, without a duplicate page title. */
add_filter( 'render_block_core/post-title', function ( string $html, array $block, $instance ): string {
    if ( ! function_exists( 'is_account_page' ) || ! is_account_page() || ! is_user_logged_in() ) { return $html; }
    $is_page_title = (int) ( $instance->context['postId'] ?? 0 ) === (int) wc_get_page_id( 'myaccount' );
    return $is_page_title ? '' : $html;
}, 10, 3 );

/** Keep the native endpoint registry, including independent module destinations. */
add_filter( 'woocommerce_account_menu_items', function ( array $items ): array {
    if ( isset( $items['dashboard'] ) ) { $items['dashboard'] = __( 'Overview', 'codela-storefront' ); }
    // Keep WooCommerce's real edit-account endpoint; only improve the label
    // shown by both the native menu and the Codela account appearance.
    if ( isset( $items['edit-account'] ) ) { $items['edit-account'] = __( 'Account information', 'codela-storefront' ); }
    // Menu visibility only, never revoke native WooCommerce download permissions.
    $settings = function_exists( 'codela_theme_settings' ) ? codela_theme_settings() : [];
    if ( is_array( $settings ) && in_array( $settings['account_downloads_enabled'] ?? true, [ false, 0, '0', '' ], true ) ) {
        unset( $items['downloads'] );
    }
    return $items;
}, 20 );
add_filter( 'body_class', function ( array $classes ): array {
    if ( function_exists( 'is_account_page' ) && is_account_page() && is_user_logged_in() && ! is_wc_endpoint_url() ) {
        $classes[] = 'sf-account-dashboard';
    }
    return $classes;
} );

/**
 * WooCommerce 11+ retains ownership of sending and validating verification.
 * Relocate only its full-size Orders prompt to the account overview.
 */
function codela_sf_verification_controller() {
    $hook = $GLOBALS['wp_filter']['woocommerce_before_account_orders'] ?? null;
    if ( ! is_object( $hook ) || ! isset( $hook->callbacks ) || ! is_array( $hook->callbacks ) ) { return null; }
    foreach ( $hook->callbacks as $callbacks ) {
        foreach ( $callbacks as $callback ) {
            $handler = $callback['function'] ?? null;
            if ( is_array( $handler ) && isset( $handler[0], $handler[1] )
                && is_object( $handler[0] ) && 'render_prompt' === $handler[1]
                && is_a( $handler[0], 'Automattic\\WooCommerce\\Internal\\CustomerEmailVerification\\VerificationController' ) ) {
                return $handler[0];
            }
        }
    }
    return null;
}
add_action( 'template_redirect', static function(): void {
    if ( ! is_user_logged_in() || ! function_exists( 'is_wc_endpoint_url' )
        || ! is_account_page() || ! is_wc_endpoint_url( 'orders' ) ) { return; }
    $controller = codela_sf_verification_controller();
    if ( $controller ) {
        remove_action( 'woocommerce_before_account_orders', [ $controller, 'render_prompt' ], 10 );
    }
}, 15 );

function codela_sf_account_verification_banner(): void {
    if ( ! is_user_logged_in() || ! is_account_page() ) { return; }
    $controller = codela_sf_verification_controller();
    if ( ! $controller || ! $controller->should_show_prompt() ) { return; }
    $send_url = wp_nonce_url(
        add_query_arg( 'wc_send_verification', '1', wc_get_account_endpoint_url( 'orders' ) ),
        'woocommerce-send-verification-email'
    );
    ?>
    <aside class="sf-account-verify-banner" data-sf-verify-banner
        data-sf-verify-dismiss-key="sf-account-verify-<?php echo (int) get_current_user_id(); ?>"
        aria-label="<?php esc_attr_e( 'Email verification', 'codela-storefront' ); ?>">
        <span class="sf-account-verify-copy"><?php esc_html_e( 'Confirm your email to link past orders to your account.', 'codela-storefront' ); ?></span>
        <a class="sf-account-verify-action" href="<?php echo esc_url( $send_url ); ?>"><?php esc_html_e( 'Send confirmation email', 'codela-storefront' ); ?></a>
        <button type="button" class="sf-account-verify-dismiss" data-sf-verify-dismiss
            aria-label="<?php esc_attr_e( 'Dismiss reminder', 'codela-storefront' ); ?>">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"
                stroke-linecap="round" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6L6 18"/></svg>
        </button>
    </aside>
    <?php
}

/** Shared local icon vocabulary; unknown plugin destinations remain real links. */
function codela_sf_account_icon( string $endpoint ): string {
    $icons = [ 'dashboard' => 'house', 'orders' => 'account-orders', 'downloads' => 'download', 'communication-preferences' => 'account-preferences', 'privacy' => 'account-preferences', 'edit-address' => 'account-address', 'edit-account' => 'account-profile', 'guvenlik' => 'account-security', 'customer-logout' => 'account-sign-out' ];
    return codela_sf_icon( $icons[ $endpoint ] ?? 'arrow-right' );
}


/** Current endpoint is a content heading; the header names its parent. */
add_action( 'woocommerce_account_content', function (): void {
    if ( ! is_user_logged_in() || ! function_exists( 'WC' ) || ! WC()->query ) { return; }
    $endpoint = WC()->query->get_current_endpoint();
    if ( ! $endpoint ) { return; }
    $items = wc_get_account_menu_items();
    $title = $items[ $endpoint ] ?? WC()->query->get_endpoint_title( $endpoint );
    if ( $title ) { echo '<h1 class="sf-account-endpoint-title">' . esc_html( $title ) . '</h1>'; }
}, 5 );


// Explain disabled WooCommerce customer registration INSIDE the Codela admin
// settings screen. Never display this notice to the site's visitors or
// enable registration behind the merchant's back.
function codela_sf_registration_settings_notice(): void {
    if ( ! current_user_can( 'manage_woocommerce' )
        || ! function_exists( 'get_option' )
        || 'yes' === get_option( 'woocommerce_enable_myaccount_registration', 'no' ) ) { return; }

    $page = isset( $_GET['page'] ) && is_string( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
    $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
    $screen_id = $screen && isset( $screen->id ) ? (string) $screen->id : '';
    $is_codela = str_contains( $page, 'codela' ) || str_contains( $screen_id, 'codela' );
    if ( ! $is_codela ) { return; }

    $settings_url = admin_url( 'admin.php?page=wc-settings&tab=account' );
    echo '<div class="notice notice-warning codela-sf-registration-warning"><p><strong>'
        . esc_html__( 'Customer registration is disabled in WooCommerce.', 'codela-storefront' )
        . '</strong> '
        . esc_html__( 'The email registration action is hidden until account creation on the My Account page is enabled.', 'codela-storefront' )
        . ' <a href="' . esc_url( $settings_url ) . '">'
        . esc_html__( 'Open WooCommerce account settings', 'codela-storefront' )
        . '</a></p></div>';
}
add_action( 'admin_notices', 'codela_sf_registration_settings_notice' );
