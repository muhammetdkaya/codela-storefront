/**
 * Progressive enhancement of marked links using WordPress's *native* router.
 * Not a second router or SPA: unsupported destinations use real document loads.
 */
import { store, watch } from '@wordpress/interactivity';
const { state: routerState } = store('core/router');
const REGION = '#sf-content[data-wp-router-region="codela/storefront/main"]';
let navigationGeneration = 0;
let feedbackToken = null;
let previousUrl = routerState.url || location.href;

function sameDocument(url) {
    const here = new URL(location.href);
    return url.origin === here.origin && url.pathname === here.pathname && url.search === here.search;
}
function allowedClick(event, link) {
    if (!link || event.defaultPrevented || event.button !== 0 ||
        event.metaKey || event.ctrlKey || event.shiftKey || event.altKey ||
        link.target && link.target !== '_self' || link.hasAttribute('download') ||
        link.closest('[contenteditable],form') || !document.querySelector(REGION)) return false;
    let url;
    try { url = new URL(link.href, location.href); } catch { return false; }
    return ['http:', 'https:'].includes(url.protocol) && url.origin === location.origin &&
        !url.hash && !sameDocument(url);
}
function applyLocation(from) {
    const main = document.querySelector(REGION);
    if (!main) return;
    const home = document.querySelector('.sf-dock-item[data-dock-view="home"]');
    const here = new URL(routerState.url || location.href, location.href);
    const homeUrl = home && new URL(home.href);
    const isHome = !!homeUrl && homeUrl.origin === here.origin &&
        homeUrl.pathname.replace(/\/$/, '') === here.pathname.replace(/\/$/, '');
    if (home) {
        if (isHome) home.setAttribute('aria-current', 'page');
        else home.removeAttribute('aria-current');
    }
    document.querySelectorAll('.sf-shell').forEach(shell => {
        shell.dataset.sfCurrentPage = main.dataset.sfRouteType || 'page';
    });
    // These few classes are used by WordPress/theme styles; native router
    // regions do not promise that document.body is replaced.
    document.body.classList.toggle('home', isHome);
    document.body.classList.toggle('front-page', isHome);
    document.body.classList.toggle('page', !isHome);
    window.dispatchEvent(new CustomEvent('codela:route-committed', { detail: { from, to: here.href } }));
}
function finishLoading() {
    window.codelaSFFeedback?.end(feedbackToken);
    feedbackToken = null;
}
function commitLocation({ focus = false } = {}) {
    const url = routerState.url || location.href;
    const from = previousUrl;
    const changed = from !== url;
    previousUrl = url;
    const main = document.querySelector(REGION);
    if (!main) return;
    if (changed) applyLocation(from);
    // Explicit clicks start at the new content. History traversal keeps the
    // browser/core scroll restoration and focus rather than forcing the top.
    if (focus) {
        window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
        main.setAttribute('tabindex', '-1');
        main.focus({ preventScroll: true });
    }
}
// URL is public across supported core versions; lifecycle flags are not.
// Explicit clicks use the native navigate() promise for loading feedback.
// The URL watcher also handles native router history traversal.
watch(() => {
    const url = routerState.url || location.href;
    if (previousUrl !== url && !window.codelaSFFeedback?.active(feedbackToken)) {
        commitLocation();
    }
});
// Document delegation survives successive region replacements. Route only
// explicitly marked links: ordinary Woo/product/auth/checkout links stay native.
document.addEventListener('click', event => {
    const link = event.target.closest?.('a[data-sf-route]');
    if (!allowedClick(event, link)) return;
    event.preventDefault();
    const url = link.href;
    const generation = ++navigationGeneration;
    finishLoading();
    feedbackToken = window.codelaSFFeedback?.begin({ url, link, owner: 'router' });
    const token = feedbackToken;
    let fallingBack = false;
    // Dynamic import means the router is paid for only on actual navigation.
    import('@wordpress/interactivity-router').then(({actions}) =>
        actions.navigate(url, { timeout: 7000, loadingAnimation: false })
    ).catch(() => {
        if (generation !== navigationGeneration || token != null && !window.codelaSFFeedback?.active(token)) return;
        // No custom fetch/caching: if the router module cannot load, restore
        // normal navigation for this click.
        fallingBack = true;
        window.location.assign(url);
    }).finally(() => {
        if (generation !== navigationGeneration || fallingBack) return;
        const ownsFeedback = window.codelaSFFeedback?.active(token);
        if (ownsFeedback) {
            finishLoading();
            commitLocation({ focus: true });
        } else feedbackToken = null;
    });
});
